<?php
$title = 'Gestion de roles';
require_once __DIR__.'/../../includes/session.php';
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../templates/header.php';

if ($_SESSION['rol'] !== 'Administrador') {
    echo "<div class='alert alert-danger'>Acceso denegado.</div>";
    require_once __DIR__.'/../../templates/footer.php';
    exit;
}

$result = $conexion->query("SELECT id, nombre FROM roles ORDER BY id");
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="h4">Gestión de roles</h2>
  <a href="<?= BASE_URL ?>admin/roles/form.php" class="btn btn-primary">+ Nuevo rol</a>
</div>
<table class="table table-striped">
  <thead class="table-dark"><tr><th>ID</th><th>Nombre</th><th style="width:150px">Acciones</th></tr></thead>
  <tbody>
    <?php while ($r = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $r['id'] ?></td>
      <td><?= htmlspecialchars($r['nombre']) ?></td>
      <td>
        <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>admin/roles/form.php?id=<?= $r['id'] ?>">Editar</a>
        <a class="btn btn-sm btn-outline-danger" href="<?= BASE_URL ?>includes/role_delete.php?id=<?= $r['id'] ?>" onclick="return confirm('¿Eliminar este rol?')">Eliminar</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
<?php require_once __DIR__.'/../../templates/footer.php'; ?>
