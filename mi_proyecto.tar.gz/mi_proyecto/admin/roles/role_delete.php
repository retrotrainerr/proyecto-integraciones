<?php
session_start();
require_once '../../config/config.php';
require_once '../../includes/auth.php';

// Verificar si el usuario está autenticado y tiene permisos de administrador
checkAdminAuth();

// Configurar el header para devolver JSON
header('Content-Type: application/json');

try {
    // Validar que se recibió el ID del rol
    if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
        throw new Exception('ID de rol inválido');
    }

    $id = intval($_POST['id']);

    // Verificar si el rol está siendo usado por usuarios
    $checkQuery = "SELECT COUNT(*) as count FROM usuarios WHERE rol_id = ?";
    $stmt = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if ($row['count'] > 0) {
        throw new Exception('No se puede eliminar el rol porque está asignado a uno o más usuarios');
    }

    // Eliminar el rol
    $query = "DELETE FROM roles WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception('Error al eliminar el rol: ' . mysqli_error($conn));
    }

    if (mysqli_affected_rows($conn) === 0) {
        throw new Exception('El rol no existe o ya fue eliminado');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Rol eliminado exitosamente'
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 