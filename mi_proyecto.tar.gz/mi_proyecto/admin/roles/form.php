<?php
require_once '../../includes/session.php';
require_once '../../includes/config.php';
require_once '../../templates/header.php';

if ($_SESSION['rol'] !== 'Administrador') {
    echo "<div class='alert alert-danger'>Acceso denegado.</div>";
    require_once '../../templates/footer.php';
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$nombre = '';

if ($id > 0) {
    $stmt = $conexion->prepare("SELECT nombre FROM roles WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($nombre);
    if (!$stmt->fetch()) {
        echo "<div class='alert alert-danger'>Rol no encontrado.</div>";
        require_once '../../templates/footer.php';
        exit;
    }
    $stmt->close();
}
?>
<h2 class="h4"><?= $id > 0 ? 'Editar rol' : 'Nuevo rol' ?></h2>
<form method="post" action="../../includes/role_save.php">
  <input type="hidden" name="id" value="<?= $id ?>">
  <div class="mb-3">
    <label class="form-label">Nombre del rol</label>
    <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($nombre) ?>" required>
  </div>
  <button class="btn btn-success">Guardar</button>
  <a href="index.php" class="btn btn-secondary">Cancelar</a>
</form>
<?php require_once '../../templates/footer.php'; ?>
