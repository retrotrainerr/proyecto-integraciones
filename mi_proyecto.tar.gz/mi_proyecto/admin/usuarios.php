<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth.php';

// Verificar si el usuario está autenticado y tiene permisos de administrador
checkAdminAuth();

$title = "Administración de Usuarios";
include '../includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Administración de Usuarios</h1>
                <a href="usuarios/user_form.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Nuevo Usuario
                </a>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Email</th>
                                    <th>Rol</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT u.*, r.nombre as rol_nombre 
                                         FROM usuarios u 
                                         LEFT JOIN roles r ON u.rol_id = r.id 
                                         ORDER BY u.id DESC";
                                $result = mysqli_query($conn, $query);

                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>{$row['id']}</td>";
                                    echo "<td>{$row['nombre']}</td>";
                                    echo "<td>{$row['email']}</td>";
                                    echo "<td>{$row['rol_nombre']}</td>";
                                    echo "<td>" . ($row['activo'] ? 'Activo' : 'Inactivo') . "</td>";
                                    echo "<td>
                                            <a href='usuarios/user_form.php?id={$row['id']}' class='btn btn-sm btn-info'>
                                                <i class='fas fa-edit'></i>
                                            </a>
                                            <button onclick='deleteUser({$row['id']})' class='btn btn-sm btn-danger'>
                                                <i class='fas fa-trash'></i>
                                            </button>
                                          </td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function deleteUser(id) {
    if (confirm('¿Está seguro de que desea eliminar este usuario?')) {
        fetch(`usuarios/user_delete.php?id=${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error al eliminar el usuario: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al eliminar el usuario');
        });
    }
}
</script>

<?php include '../includes/footer.php'; ?> 