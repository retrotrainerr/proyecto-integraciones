<?php
require_once '../../includes/session.php';
require_once '../../includes/config.php';

// Verificar que el usuario sea administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'Administrador') {
    $_SESSION['error'] = "Acceso denegado. Se requieren permisos de administrador.";
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            switch ($_POST['action']) {
                case 'create':
                    if (!empty($_POST['nombre'])) {
                        $stmt = $conexion->prepare("INSERT INTO grupos (nombre) VALUES (?)");
                        $stmt->bind_param("s", $_POST['nombre']);
                        if ($stmt->execute()) {
                            $mensaje = "Grupo creado exitosamente.";
                            $tipo_mensaje = "success";
                        }
                    }
                    break;
                
                case 'update':
                    if (!empty($_POST['id']) && !empty($_POST['nombre'])) {
                        $stmt = $conexion->prepare("UPDATE grupos SET nombre = ? WHERE id = ?");
                        $stmt->bind_param("si", $_POST['nombre'], $_POST['id']);
                        if ($stmt->execute()) {
                            $mensaje = "Grupo actualizado exitosamente.";
                            $tipo_mensaje = "success";
                        }
                    }
                    break;
                
                case 'delete':
                    if (!empty($_POST['id'])) {
                        // Primero mover usuarios a grupo por defecto
                        $stmt = $conexion->prepare("UPDATE usuarios SET grupo_id = 1 WHERE grupo_id = ?");
                        $stmt->bind_param("i", $_POST['id']);
                        $stmt->execute();
                        
                        // Luego eliminar el grupo
                        $stmt = $conexion->prepare("DELETE FROM grupos WHERE id = ?");
                        $stmt->bind_param("i", $_POST['id']);
                        if ($stmt->execute()) {
                            $mensaje = "Grupo eliminado exitosamente.";
                            $tipo_mensaje = "success";
                        }
                    }
                    break;
            }
        } catch (Exception $e) {
            $mensaje = "Error: " . $e->getMessage();
            $tipo_mensaje = "danger";
        }
    }
}

// Obtener lista de grupos
$grupos = [];
try {
    $result = $conexion->query("SELECT g.*, COUNT(u.id) as total_usuarios 
                           FROM grupos g 
                           LEFT JOIN usuarios u ON g.id = u.grupo_id 
                           GROUP BY g.id 
                           ORDER BY g.nombre");
    while ($row = $result->fetch_assoc()) {
        $grupos[] = $row;
    }
} catch (Exception $e) {
    $mensaje = "Error al cargar los grupos: " . $e->getMessage();
    $tipo_mensaje = "danger";
}

$title = "Gestión de Grupos";
require_once '../../templates/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Gestión de Grupos</h2>
                <a href="<?= BASE_URL ?>dashboard.php" class="btn btn-secondary">Volver al Dashboard</a>
            </div>

            <?php if ($mensaje): ?>
            <div class="alert alert-<?= $tipo_mensaje ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($mensaje) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            
            <!-- Formulario para crear nuevo grupo -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Crear Nuevo Grupo</h5>
                </div>
                <div class="card-body">
                    <form method="POST" class="row g-3">
                        <input type="hidden" name="action" value="create">
                        <div class="col-md-8">
                            <input type="text" name="nombre" class="form-control" placeholder="Nombre del grupo" required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-plus-circle"></i> Crear Grupo
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Lista de grupos -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Grupos Existentes</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($grupos)): ?>
                    <div class="alert alert-info">No hay grupos registrados.</div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Total Usuarios</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($grupos as $grupo): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($grupo['id']); ?></td>
                                    <td>
                                        <form method="POST" class="row g-3 align-items-center" id="form-edit-<?php echo $grupo['id']; ?>">
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="id" value="<?php echo $grupo['id']; ?>">
                                            <div class="col-auto flex-grow-1">
                                                <input type="text" name="nombre" class="form-control form-control-sm" 
                                                       value="<?php echo htmlspecialchars($grupo['nombre']); ?>" required>
                                            </div>
                                            <div class="col-auto">
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="bi bi-check"></i>
                                                </button>
                                            </div>
                                        </form>
                                    </td>
                                    <td><?php echo $grupo['total_usuarios']; ?></td>
                                    <td>
                                        <?php if ($grupo['id'] != 1): // Evitar eliminar el grupo por defecto ?>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro? Los usuarios serán movidos al grupo por defecto.');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?php echo $grupo['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../templates/footer.php'; ?> 