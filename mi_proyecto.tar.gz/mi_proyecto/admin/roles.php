<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth.php';

// Verificar si el usuario está autenticado y tiene permisos de administrador
checkAdminAuth();

$title = "Administración de Roles";
include '../includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Administración de Roles</h1>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#rolModal">
                    <i class="fas fa-plus"></i> Nuevo Rol
                </button>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM roles ORDER BY id DESC";
                                $result = mysqli_query($conn, $query);

                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>{$row['id']}</td>";
                                    echo "<td>{$row['nombre']}</td>";
                                    echo "<td>{$row['descripcion']}</td>";
                                    echo "<td>
                                            <button onclick='editRole({$row['id']}, \"{$row['nombre']}\", \"{$row['descripcion']}\")' 
                                                    class='btn btn-sm btn-info'>
                                                <i class='fas fa-edit'></i>
                                            </button>
                                            <button onclick='deleteRole({$row['id']})' class='btn btn-sm btn-danger'>
                                                <i class='fas fa-trash'></i>
                                            </button>
                                          </td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Crear/Editar Rol -->
<div class="modal fade" id="rolModal" tabindex="-1" aria-labelledby="rolModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rolModalLabel">Nuevo Rol</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="rolForm">
                    <input type="hidden" id="rolId" name="id">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="saveRole()">Guardar</button>
            </div>
        </div>
    </div>
</div>

<script>
function editRole(id, nombre, descripcion) {
    document.getElementById('rolId').value = id;
    document.getElementById('nombre').value = nombre;
    document.getElementById('descripcion').value = descripcion;
    document.getElementById('rolModalLabel').textContent = 'Editar Rol';
    new bootstrap.Modal(document.getElementById('rolModal')).show();
}

function saveRole() {
    const formData = new FormData(document.getElementById('rolForm'));
    const id = formData.get('id');
    
    fetch('roles/role_save.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error al guardar el rol: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el rol');
    });
}

function deleteRole(id) {
    if (confirm('¿Está seguro de que desea eliminar este rol?')) {
        fetch(`roles/role_delete.php?id=${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error al eliminar el rol: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al eliminar el rol');
        });
    }
}
</script>

<?php include '../includes/footer.php'; ?> 