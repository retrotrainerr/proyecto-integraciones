<?php
$title = 'Usuarios';
require_once __DIR__.'/../../includes/session.php';
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../templates/header.php';

if ($_SESSION['rol'] !== 'Administrador') {
    echo "<div class='alert alert-danger'>Acceso denegado. Solo el rol 'Administrador' puede acceder.</div>";
    require_once __DIR__.'/../../templates/footer.php';
    exit;
}

$result = $conexion->query("SELECT id, usuario FROM usuarios ORDER BY id");
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="h4">Gestión de usuarios</h2>
  <a class="btn btn-primary" href="<?= BASE_URL ?>admin/usuarios/user_form.php">+ Nuevo usuario</a>
</div>

<table class="table table-striped">
  <thead class="table-dark"><tr><th>ID</th><th>Usuario</th><th style="width:160px">Acciones</th></tr></thead>
  <tbody>
  <?php while($u=$result->fetch_assoc()): ?>
    <tr>
      <td><?= $u['id'] ?></td>
      <td><?= htmlspecialchars($u['usuario']) ?></td>
      <td>
        <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>admin/usuarios/user_form.php?id=<?= $u['id'] ?>">Editar</a>
        <a class="btn btn-sm btn-outline-danger" href="<?= BASE_URL ?>includes/user_delete.php?id=<?= $u['id'] ?>" onclick="return confirm('¿Eliminar usuario?')">Eliminar</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
<?php require_once __DIR__.'/../../templates/footer.php'; ?>
