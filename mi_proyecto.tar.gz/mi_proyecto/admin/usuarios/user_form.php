<?php
require_once __DIR__.'/../../includes/session.php';
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../templates/header.php';

$editing = isset($_GET['id']);
$id = $editing ? intval($_GET['id']) : 0;
$usuario = '';

if ($editing) {
    $stmt = $conexion->prepare("SELECT usuario FROM usuarios WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->bind_result($usuario);
    if(!$stmt->fetch()){ echo '<div class="alert alert-danger">Usuario no encontrado</div>'; require_once __DIR__.'/../../templates/footer.php'; exit; }
    $stmt->close();
}
if ($_SESSION['rol'] !== 'Administrador') {
    echo "<div class='alert alert-danger'>Acceso denegado. Solo el rol 'Administrador' puede acceder.</div>";
    require_once __DIR__.'/../../templates/footer.php';
    exit;
}

?>
<h2 class="h4 mb-3"><?= $editing ? 'Editar usuario' : 'Nuevo usuario' ?></h2>
<form method="post" action="user_save.php">
  <input type="hidden" name="id" value="<?= $id ?>">
    <div class="mb-3">
    <label class="form-label">Rol</label>
    <select name="rol_id" class="form-select">
    <?php
      $roles = $conexion->query("SELECT id, nombre FROM roles");
      while ($r = $roles->fetch_assoc()):
      $selected = ($r['id'] == $rol_id) ? 'selected' : '';
        ?>
        <option value="<?= $r['id'] ?>" <?= $selected ?>>
        <?= htmlspecialchars($r['nombre']) ?>
        </option>
      <?php endwhile; ?>
      </select>
    </div>
    <label class="form-label">Nombre de usuario</label>
    <input type="text" class="form-control" name="usuario" value="<?= htmlspecialchars($usuario) ?>" required>
    <label class="form-label">Contraseña <?= $editing ? '(dejar en blanco para no cambiar)' : '' ?></label>
    <input type="password" class="form-control" name="clave" <?= $editing ? '' : 'required' ?>>
  </div>
  <button class="btn btn-success">Guardar</button>
  <a class="btn btn-secondary" href="<?= BASE_URL ?>admin/usuarios/users.php">Cancelar</a>
</form>
<?php require_once __DIR__.'/../../templates/footer.php'; ?>
