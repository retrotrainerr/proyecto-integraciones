<?php
require_once 'session.php';
require_once 'config.php';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($id>0){
    $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
}
header('Location: ../admin/users.php');
?>
