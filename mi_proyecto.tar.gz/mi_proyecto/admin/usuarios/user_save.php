<?php
require_once __DIR__.'/../../includes/session.php';
require_once __DIR__.'/../../includes/config.php';

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$usuario = trim($_POST['usuario'] ?? '');
$clave   = $_POST['clave'] ?? '';
$rol_id  = isset($_POST['rol_id']) ? intval($_POST['rol_id']) : null;

if($usuario === '') { die('Usuario requerido'); }
if($rol_id === 0)   { die('Rol no válido'); }

if($id === 0){
    if($clave === '') { die('Contraseña requerida'); }
    $hash = password_hash($clave, PASSWORD_DEFAULT);
    $stmt = $conexion->prepare("INSERT INTO usuarios (usuario, clave, rol_id) VALUES (?, ?, ?)");
    $stmt->bind_param('ssi', $usuario, $hash, $rol_id);
} else {
    if($clave !== ''){
        $hash = password_hash($clave, PASSWORD_DEFAULT);
        $stmt = $conexion->prepare("UPDATE usuarios SET usuario=?, clave=?, rol_id=? WHERE id=?");
        $stmt->bind_param('ssii', $usuario, $hash, $rol_id, $id);
    } else {
        $stmt = $conexion->prepare("UPDATE usuarios SET usuario=?, rol_id=? WHERE id=?");
        $stmt->bind_param('sii', $usuario, $rol_id, $id);
    }
}
$stmt->execute();
$stmt->close();
header('Location: ' . BASE_URL . 'admin/usuarios/users.php');
?>
