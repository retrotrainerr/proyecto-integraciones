<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Iniciar sesión</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f0f2f5;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-box {
      background: white;
      padding: 2rem;
      border-radius: 1rem;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .logo {
      max-height: 80px;
      margin-bottom: 1rem;
    }
  </style>
</head>
<body>

<div class="login-box">
  <!-- Puedes reemplazar el logo.png por otro -->
  <img src="assets/logo.png" alt="Logo" class="logo">

  <h2 class="mb-4">Iniciar sesión</h2>
  <?php if (isset($_GET['error'])): ?>
  <div class="alert alert-danger">Usuario o clave incorrectos.</div>
  <?php endif; ?>

  <form method="post" action="includes/login.php">
    <div class="mb-3 text-start">
      <label class="form-label">Usuario</label>
      <input type="text" name="usuario" class="form-control" required>
    </div>
    <div class="mb-3 text-start">
      <label class="form-label">Clave</label>
      <input type="password" name="clave" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary w-100">Entrar</button>
  </form>
</div>

</body>
</html>
