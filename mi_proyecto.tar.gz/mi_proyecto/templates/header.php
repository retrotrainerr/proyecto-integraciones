<?php
require_once __DIR__.'/../includes/session.php';
$title = $title ?? 'Panel';
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($title) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= BASE_URL ?>dashboard.php">MiProyecto</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarContent">
      <ul class="navbar-nav me-auto">
        <?php if ($_SESSION['rol'] === 'Administrador'): ?>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/usuarios/users.php">Usuarios</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/roles/index.php">Roles</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>admin/grupos/index.php">Grupos</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>chat/index.php">Chats</a></li>
        <?php endif; ?>
      </ul>
      <span class="navbar-text me-3"><?= htmlspecialchars($_SESSION['usuario']) ?> (<?= $_SESSION['rol'] ?>)</span>
      <a class="btn btn-outline-light btn-sm" href="<?= BASE_URL ?>logout.php">Salir</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
