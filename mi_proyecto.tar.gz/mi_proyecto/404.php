<?php
$title = "Página no encontrada";
require_once 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <h1 class="display-1">404</h1>
            <h2>Página no encontrada</h2>
            <p class="lead">Lo sentimos, la página que buscas no existe.</p>
            <a href="<?= BASE_URL ?>dashboard.php" class="btn btn-primary">Volver al Dashboard</a>
        </div>
    </div>
</div>

<?php require_once 'templates/footer.php'; ?> 