<?php
require_once '../includes/session.php';
require_once '../includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id']) || !isset($_GET['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Datos incompletos']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$otro_usuario = intval($_GET['usuario_id']);
$es_admin = isset($_SESSION['es_admin']) ? $_SESSION['es_admin'] : 0;
$grupo_id = isset($_SESSION['grupo_id']) ? $_SESSION['grupo_id'] : null;

try {
    // Verificar que el usuario existe y obtener su información
    $stmt = $conexion->prepare("
        SELECT u.*, r.nombre as rol_nombre
        FROM usuarios u
        LEFT JOIN roles r ON u.rol_id = r.id
        WHERE u.id = ?
    ");
    $stmt->bind_param("i", $otro_usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    $otro_usuario_info = $result->fetch_assoc();

    if (!$otro_usuario_info) {
        echo json_encode(['success' => false, 'error' => 'Usuario no encontrado']);
        exit;
    }

    // Si no es administrador, verificar restricciones
    if (!$es_admin) {
        // Verificar que ambos usuarios pertenecen al mismo grupo
        if ($grupo_id != $otro_usuario_info['grupo_id']) {
            echo json_encode(['success' => false, 'error' => 'No puedes ver mensajes de usuarios de otros grupos']);
            exit;
        }

        // Verificar roles permitidos
        $mi_rol = isset($_SESSION['rol']) ? $_SESSION['rol'] : null;
        if ($mi_rol === 'Usuario' && $otro_usuario_info['rol_nombre'] !== 'Supervisor') {
            echo json_encode(['success' => false, 'error' => 'Como usuario solo puedes chatear con supervisores']);
            exit;
        }
    }

    // Obtener mensajes
    $stmt = $conexion->prepare("
        SELECT 
            m.id,
            m.emisor_id,
            m.receptor_id,
            m.mensaje,
            m.fecha_envio,
            m.leido,
            u1.usuario as emisor_nombre,
            u2.usuario as receptor_nombre,
            u1.rol_id as emisor_rol_id,
            u2.rol_id as receptor_rol_id
        FROM mensajes m
        INNER JOIN usuarios u1 ON m.emisor_id = u1.id
        INNER JOIN usuarios u2 ON m.receptor_id = u2.id
        WHERE (m.emisor_id = ? AND m.receptor_id = ?)
        OR (m.emisor_id = ? AND m.receptor_id = ?)
        ORDER BY m.fecha_envio ASC
    ");
    
    $stmt->bind_param("iiii", $usuario_id, $otro_usuario, $otro_usuario, $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $mensajes = [];
    while ($row = $result->fetch_assoc()) {
        $mensajes[] = [
            'id' => intval($row['id']),
            'emisor_id' => intval($row['emisor_id']),
            'receptor_id' => intval($row['receptor_id']),
            'mensaje' => $row['mensaje'],
            'fecha_envio' => $row['fecha_envio'],
            'leido' => intval($row['leido']),
            'emisor_nombre' => $row['emisor_nombre'],
            'receptor_nombre' => $row['receptor_nombre']
        ];
    }

    // Marcar mensajes como leídos
    $stmt = $conexion->prepare("
        UPDATE mensajes 
        SET leido = 1 
        WHERE emisor_id = ? AND receptor_id = ? AND leido = 0
    ");
    $stmt->bind_param("ii", $otro_usuario, $usuario_id);
    $stmt->execute();

    echo json_encode([
        'success' => true, 
        'mensajes' => $mensajes,
        'total' => count($mensajes)
    ]);
    
} catch (Exception $e) {
    error_log("Error en get_mensajes.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'error' => 'Error al obtener mensajes: ' . $e->getMessage()
    ]);
}
?>