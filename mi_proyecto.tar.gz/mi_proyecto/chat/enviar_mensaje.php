<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../includes/config.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Función para registrar en el log
function logError($mensaje, $datos = []) {
    error_log("[CHAT_DEBUG] " . $mensaje . " - Datos: " . print_r($datos, true));
}

// Log inicial para verificar que el script se está ejecutando
logError("Script iniciado", [
    'POST' => $_POST,
    'FILES' => isset($_FILES) ? array_keys($_FILES) : 'No hay archivos',
    'SESSION' => $_SESSION,
    'PERMISOS_USUARIO' => [
        'es_admin' => $_SESSION['es_admin'] ?? 'no definido',
        'rol' => $_SESSION['rol'] ?? 'no definido',
        'grupo_id' => $_SESSION['grupo_id'] ?? 'no definido',
        'usuario' => $_SESSION['usuario'] ?? 'no definido'
    ]
]);

if (!isset($_SESSION['usuario_id'])) {
    logError("No hay sesión activa");
    echo json_encode(['error' => 'No hay sesión activa']);
    exit;
}

$de = $_SESSION['usuario_id'];
$para = intval($_POST['para'] ?? 0);
$mensaje = trim($_POST['mensaje'] ?? '');

if ($para === 0) {
    logError("Destinatario no válido", ['para' => $_POST['para'] ?? null]);
    echo json_encode(['error' => 'Destinatario no válido']);
    exit;
}

// Variable para rastrear si tenemos contenido para enviar
$tieneContenido = !empty($mensaje);
$rutaArchivo = '';

// Manejar archivo adjunto si existe
if (!empty($_FILES['archivo']['name'])) {
    $archivo = $_FILES['archivo'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    logError("Intentando procesar archivo", [
        'nombre' => $archivo['name'],
        'tipo' => $archivo['type'],
        'tamaño' => $archivo['size'],
        'error' => $archivo['error']
    ]);
    
    // Validar el archivo
    if ($archivo['error'] !== UPLOAD_ERR_OK) {
        logError("Error en la carga del archivo", ['codigo_error' => $archivo['error']]);
        echo json_encode(['error' => 'Error al subir el archivo: ' . obtenerErrorArchivo($archivo['error'])]);
        exit;
    }
    
    if ($archivo['size'] > $maxSize) {
        logError("Archivo demasiado grande", ['tamaño' => $archivo['size'], 'maximo' => $maxSize]);
        echo json_encode(['error' => 'El archivo excede el tamaño máximo permitido (5MB)']);
        exit;
    }
    
    // Crear directorio si no existe
    $directorioUploads = __DIR__ . '/uploads';
    if (!file_exists($directorioUploads)) {
        logError("Intentando crear directorio de uploads", ['ruta' => $directorioUploads]);
        if (!mkdir($directorioUploads, 0777, true)) {
            logError("Error al crear directorio de uploads", ['ruta' => $directorioUploads]);
            echo json_encode(['error' => 'Error al crear el directorio de uploads']);
            exit;
        }
    }
    
    // Generar nombre único para el archivo
    $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
    $nombreArchivo = time() . '_' . uniqid() . '.' . $extension;
    $rutaArchivo = $directorioUploads . '/' . $nombreArchivo;
    
    logError("Intentando mover archivo", [
        'origen' => $archivo['tmp_name'],
        'destino' => $rutaArchivo
    ]);
    
    // Intentar mover el archivo
    if (!move_uploaded_file($archivo['tmp_name'], $rutaArchivo)) {
        logError("Error al mover el archivo", [
            'permisos_directorio' => decodificarPermisos(fileperms($directorioUploads)),
            'espacio_disponible' => disk_free_space($directorioUploads)
        ]);
        echo json_encode(['error' => 'Error al guardar el archivo']);
        exit;
    }
    
    // Añadir enlace al archivo en el mensaje
    $rutaRelativa = 'uploads/' . $nombreArchivo;
    $mensaje = trim($mensaje); // Eliminar espacios en blanco
    if (!empty($mensaje)) {
        $mensaje .= '<br>';
    }
    $mensaje .= '<div class="adjunto-mensaje">
        <a href="' . htmlspecialchars($rutaRelativa) . '" target="_blank" class="archivo-adjunto" download>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paperclip" viewBox="0 0 16 16">
                <path d="M4.5 3a2.5 2.5 0 0 1 5 0v9a1.5 1.5 0 0 1-3 0V5a.5.5 0 0 1 1 0v7a.5.5 0 0 0 1 0V3a1.5 1.5 0 1 0-3 0v9a2.5 2.5 0 0 0 5 0V5a.5.5 0 0 1 1 0v7a3.5 3.5 0 1 1-7 0z"/>
            </svg>
            <span>' . htmlspecialchars($archivo['name']) . '</span>
        </a>
    </div>';
    $tieneContenido = true;
    
    logError("Archivo procesado exitosamente", [
        'ruta_relativa' => $rutaRelativa,
        'nombre_original' => $archivo['name']
    ]);
}

// Verificar que hay contenido para enviar
if (!$tieneContenido) {
    logError("Intento de envío sin contenido");
    echo json_encode(['error' => 'El mensaje no puede estar vacío']);
    exit;
}

try {
    // Insertar el mensaje
    $stmt = $conexion->prepare("INSERT INTO mensajes (emisor_id, receptor_id, mensaje) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $de, $para, $mensaje);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        if ($rutaArchivo && file_exists($rutaArchivo)) {
            unlink($rutaArchivo);
        }
        logError("Error al insertar en la base de datos", ['error_mysql' => $conexion->error]);
        echo json_encode(['error' => 'Error al enviar el mensaje']);
    }
    $stmt->close();
} catch (Exception $e) {
    if ($rutaArchivo && file_exists($rutaArchivo)) {
        unlink($rutaArchivo);
    }
    logError("Excepción al enviar mensaje", ['error' => $e->getMessage()]);
    echo json_encode(['error' => 'Error: ' . $e->getMessage()]);
}

function obtenerErrorArchivo($codigo) {
    switch ($codigo) {
        case UPLOAD_ERR_INI_SIZE:
            return 'El archivo excede el tamaño máximo permitido por el servidor';
        case UPLOAD_ERR_FORM_SIZE:
            return 'El archivo excede el tamaño máximo permitido por el formulario';
        case UPLOAD_ERR_PARTIAL:
            return 'El archivo se subió parcialmente';
        case UPLOAD_ERR_NO_FILE:
            return 'No se seleccionó ningún archivo';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'Falta la carpeta temporal';
        case UPLOAD_ERR_CANT_WRITE:
            return 'Error al escribir el archivo en el disco';
        case UPLOAD_ERR_EXTENSION:
            return 'Una extensión de PHP detuvo la carga del archivo';
        default:
            return 'Error desconocido al subir el archivo';
    }
}

function decodificarPermisos($perms) {
    if (($perms & 0xC000) == 0xC000) {
        $info = 's';
    } elseif (($perms & 0xA000) == 0xA000) {
        $info = 'l';
    } elseif (($perms & 0x8000) == 0x8000) {
        $info = '-';
    } elseif (($perms & 0x6000) == 0x6000) {
        $info = 'b';
    } elseif (($perms & 0x4000) == 0x4000) {
        $info = 'd';
    } elseif (($perms & 0x2000) == 0x2000) {
        $info = 'c';
    } elseif (($perms & 0x1000) == 0x1000) {
        $info = 'p';
    } else {
        $info = 'u';
    }

    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x' ) : (($perms & 0x0800) ? 'S' : '-'));

    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x' ) : (($perms & 0x0400) ? 'S' : '-'));

    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x' ) : (($perms & 0x0200) ? 'T' : '-'));

    return $info;
}
?>
