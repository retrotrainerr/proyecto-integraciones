<?php
require_once '../includes/session.php';
require_once '../includes/config.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['grupo_id'])) {
    header('Location: ../login.php');
    exit;
}

// Obtener datos del usuario
$usuario_id = $_SESSION['usuario_id'];
$grupo_id = $_SESSION['grupo_id'];
$es_admin = isset($_SESSION['es_admin']) ? $_SESSION['es_admin'] : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - MiProyecto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/chat.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .chat-box { display: flex; height: 90vh; }
        .usuarios { width: 25%; overflow-y: auto; border-right: 1px solid #ccc; }
        .mensajes { flex: 1; display: flex; flex-direction: column; }
        .mensajes-log { flex: 1; overflow-y: auto; padding: 1rem; }
        .mensaje { margin-bottom: 1rem; }
        .mensaje-emisor { text-align: right; }
        .mensaje-receptor { text-align: left; }
        .mensaje-contenido {
            display: inline-block;
            max-width: 70%;
            padding: 10px;
            border-radius: 15px;
            text-align: left;
        }
        .mensaje-emisor .mensaje-contenido { 
            background: #007bff;
            color: white;
        }
        .mensaje-receptor .mensaje-contenido { 
            background: #f1f1f1;
            color: #333;
        }
        .mensaje-fecha {
            display: block;
            font-size: 0.8em;
            margin-top: 5px;
            opacity: 0.7;
        }
        .mensaje-texto {
            word-break: break-word;
        }
        .adjunto-mensaje {
            margin-top: 8px;
        }
        .archivo-adjunto {
            margin-top: 8px;
        }
        .archivo-adjunto:hover {
            background: rgba(255, 255, 255, 0.3);
            text-decoration: none;
        }
        .mensaje-receptor .archivo-adjunto:hover {
            background: rgba(0, 0, 0, 0.1);
        }
        .archivo-adjunto svg {
            margin-right: 8px;
            flex-shrink: 0;
        }
        .archivo-adjunto span {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 200px;
        }
        .chat-footer { padding: 15px; background: #f8f9fa; border-top: 1px solid #dee2e6; }
        .form-mensaje { display: flex; flex-direction: column; gap: 10px; }
        .mensaje-controles { display: flex; gap: 10px; align-items: center; }
        .archivo-control { display: flex; align-items: center; }
        .btn-archivo { 
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            background: #e9ecef;
            border: 1px solid #ced4da;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-archivo:hover {
            background: #dde2e6;
        }
        .nombre-archivo {
            margin-left: 8px;
            font-size: 0.875rem;
            color: #6c757d;
        }
        #archivo {
            display: none;
        }
        .error-mensaje {
            color: #dc3545;
            margin-bottom: 8px;
            display: none;
        }
        .usuarios-container {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .usuarios-header {
            padding: 1rem;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        .usuarios-list {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
        }
        .usuario-item {
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 0.5rem;
            position: relative;
        }
        .usuario-item:hover {
            background: #f8f9fa;
        }
        .usuario-item.activo {
            background: #e9ecef;
        }
        .notificacion {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: #007bff;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>
    <!-- Menú de navegación -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="../index.php">MiProyecto</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <?php if ($es_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/usuarios/users.php">Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/roles/index.php">Roles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/grupos/index.php">Grupos</a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link active" href="../chat/index.php">Chats</a>
                    </li>
                </ul>
                <div class="navbar-text text-white me-2">
                    <?php echo htmlspecialchars($_SESSION['usuario']); ?> 
                    (<?php echo isset($_SESSION['rol']) ? htmlspecialchars($_SESSION['rol']) : 'Usuario'; ?>)
                </div>
                <a href="../logout.php" class="btn btn-outline-light">Salir</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-0">
        <div class="row">
            <!-- Lista de usuarios -->
            <div class="col-md-3 p-0">
                <div class="usuarios-container">
                    <div class="usuarios-header">
                        <h4>Usuarios</h4>
                    </div>
                    <div class="usuarios-list" id="lista-usuarios">
                        <!-- Los usuarios se cargarán aquí dinámicamente -->
                    </div>
                </div>
            </div>

            <!-- Área de chat -->
            <div class="col-md-9 p-0">
                <div class="chat-container">
                    <div class="chat-header">
                        <h4 id="nombre-usuario-actual">Selecciona un usuario</h4>
                    </div>
                    
                    <!-- Mensajes -->
                    <div class="mensajes-container" id="mensajes">
                        <!-- Los mensajes se cargarán aquí dinámicamente -->
                    </div>

                    <!-- Formulario de envío -->
                    <div class="chat-footer">
                        <div id="error-mensaje" class="error-mensaje"></div>
                        <form id="form-mensaje" class="form-mensaje" enctype="multipart/form-data">
                            <input type="hidden" id="usuario_id" name="usuario_id" value="<?php echo $usuario_id; ?>">
                            <input type="hidden" id="usuario_actual" name="para">
                            <div class="mensaje-controles">
                                <input type="text" id="mensaje" name="mensaje" class="form-control" placeholder="Escribe un mensaje...">
                                <div class="archivo-control">
                                    <label for="archivo" class="btn-archivo">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paperclip" viewBox="0 0 16 16">
                                            <path d="M4.5 3a2.5 2.5 0 0 1 5 0v9a1.5 1.5 0 0 1-3 0V5a.5.5 0 0 1 1 0v7a.5.5 0 0 0 1 0V3a1.5 1.5 0 1 0-3 0v9a2.5 2.5 0 0 0 5 0V5a.5.5 0 0 1 1 0v7a3.5 3.5 0 1 1-7 0z"/>
                                        </svg>
                                        <span class="nombre-archivo" id="nombre-archivo">Adjuntar archivo</span>
                                    </label>
                                    <input type="file" id="archivo" name="archivo" class="form-control" accept="*/*" style="display: none;">
                                </div>
                                <button type="submit" class="btn btn-primary">Enviar</button>
                            </div>
                            <div id="error-archivo" class="text-danger small mt-1"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Configuración inicial
    const CONFIG = {
        usuario_id: <?php echo $usuario_id; ?>,
        es_admin: <?php echo $es_admin ? 'true' : 'false'; ?>,
        grupo_id: <?php echo $grupo_id; ?>
    };
    </script>
    <script src="js/chat.js"></script>
</body>
</html>
