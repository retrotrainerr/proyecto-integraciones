<?php
require_once '../includes/session.php';
require_once '../includes/config.php';

header('Content-Type: application/json');

// Debug: Verificar variables de sesión
error_log("Sesión actual: " . print_r($_SESSION, true));

// Verificar sesión básica
if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['grupo_id'])) {
    echo json_encode([
        'success' => false, 
        'error' => 'Sesión incompleta',
        'debug' => [
            'usuario_id' => isset($_SESSION['usuario_id']),
            'grupo_id' => isset($_SESSION['grupo_id'])
        ]
    ]);
    exit;
}

try {
    // Verificar conexión a la base de datos
    if (!$conexion) {
        throw new Exception("Error de conexión a la base de datos");
    }

    $usuario_id = $_SESSION['usuario_id'];
    $grupo_id = $_SESSION['grupo_id'];
    $es_admin = isset($_SESSION['es_admin']) ? $_SESSION['es_admin'] : 0;
    $rol = isset($_SESSION['rol']) ? $_SESSION['rol'] : null;
    
    error_log("Datos de usuario: ID=$usuario_id, Rol=$rol, Es_Admin=$es_admin, Grupo=$grupo_id");

    // Construir la consulta SQL base
    $sql = "
        SELECT 
            u.id,
            u.usuario,
            COALESCE(r.nombre, CASE 
                WHEN u.es_admin = 1 THEN 'Administrador'
                ELSE 'Usuario'
            END) as rol,
            u.grupo_id,
            (
                SELECT COUNT(*) 
                FROM mensajes m 
                WHERE m.emisor_id = u.id 
                AND m.receptor_id = ? 
                AND m.leido = 0
            ) as no_leidos
        FROM usuarios u
        LEFT JOIN roles r ON u.rol_id = r.id
        WHERE u.id != ?
    ";

    // Agregar condiciones según el rol
    if ($es_admin) {
        // El administrador puede ver a todos
        $sql .= " AND 1=1";
    } else if ($rol === 'Supervisor') {
        // Supervisor solo ve usuarios de su grupo
        $sql .= " AND u.grupo_id = ? AND u.es_admin = 0";
    } else {
        // Usuario normal solo ve supervisores de su grupo
        $sql .= " AND u.grupo_id = ? AND (r.nombre = 'Supervisor' OR u.rol_id = 3)";
    }

    $sql .= " ORDER BY u.usuario";

    error_log("SQL Query: " . $sql);

    $stmt = $conexion->prepare($sql);
    
    // Bind parameters según el rol
    if ($es_admin) {
        $stmt->bind_param("ii", $usuario_id, $usuario_id);
    } else {
        $stmt->bind_param("iii", $usuario_id, $usuario_id, $grupo_id);
    }

    if (!$stmt->execute()) {
        throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
    }

    $result = $stmt->get_result();
    
    $usuarios = [];
    while ($row = $result->fetch_assoc()) {
        $usuarios[] = [
            'id' => intval($row['id']),
            'usuario' => htmlspecialchars($row['usuario']),
            'rol' => $row['rol'],
            'grupo_id' => intval($row['grupo_id']),
            'no_leidos' => intval($row['no_leidos'])
        ];
    }
    
    error_log("Usuarios encontrados: " . count($usuarios));
    
    if (empty($usuarios)) {
        echo json_encode([
            'success' => true,
            'usuarios' => [],
            'mensaje' => 'No hay usuarios disponibles para chat',
            'debug' => [
                'es_admin' => $es_admin,
                'rol' => $rol,
                'grupo_id' => $grupo_id
            ]
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'usuarios' => $usuarios
        ]);
    }
    
} catch (Exception $e) {
    error_log("Error en get_usuarios.php: " . $e->getMessage());
    error_log("Trace: " . $e->getTraceAsString());
    echo json_encode([
        'success' => false, 
        'error' => 'Error al obtener usuarios. Por favor, recarga la página.',
        'debug_message' => $e->getMessage()
    ]);
}
?>
