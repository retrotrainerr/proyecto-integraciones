$(document).ready(function() {
    // Variables globales
    let usuarioActual = null;
    const usuarioId = $('#usuario_id').val();
    const maxFileSize = 5 * 1024 * 1024; // 5MB

    console.log('ID de usuario actual:', usuarioId);
    console.log('Configuración:', CONFIG);

    // Cargar usuarios inicialmente y cada 10 segundos
    cargarUsuarios();
    setInterval(cargarUsuarios, 10000);

    // Manejar el envío del formulario
    $('#form-mensaje').on('submit', function(e) {
        e.preventDefault();
        enviarMensaje();
    });

    // Validar tamaño del archivo antes de enviar
    $('#archivo').on('change', function() {
        console.log('Evento change del archivo disparado');
        const file = this.files[0];
        console.log('Archivo seleccionado:', file ? {
            nombre: file.name,
            tipo: file.type,
            tamaño: file.size
        } : 'No hay archivo');
        
        if (file) {
            if (file.size > maxFileSize) {
                $('#error-archivo').text('El archivo excede el tamaño máximo permitido (5MB)');
                $('#nombre-archivo').text('Adjuntar archivo');
                this.value = '';
            } else {
                $('#error-archivo').text('');
                $('#nombre-archivo').text(file.name);
            }
        } else {
            $('#nombre-archivo').text('Adjuntar archivo');
        }
    });

    function cargarUsuarios() {
        console.log('Intentando cargar usuarios...');
        $.ajax({
            url: 'get_usuarios.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                console.log('Respuesta del servidor:', response);
                if (response.success) {
                    const listaUsuarios = $('#lista-usuarios');
                    listaUsuarios.empty();
                    
                    if (response.usuarios && response.usuarios.length > 0) {
                        response.usuarios.forEach(usuario => {
                            if (usuario.id != usuarioId) { // No mostrar el usuario actual
                                const elemento = $(`
                                    <div class="usuario-item ${usuario.id === usuarioActual ? 'activo' : ''}" 
                                         data-id="${usuario.id}" 
                                         data-nombre="${usuario.usuario}">
                                        ${usuario.usuario}
                                        ${usuario.no_leidos > 0 ? 
                                            `<span class="notificacion">${usuario.no_leidos}</span>` : ''}
                                    </div>
                                `);
                                
                                listaUsuarios.append(elemento);
                            }
                        });
                    } else {
                        listaUsuarios.html('<div class="p-3 text-muted">No hay usuarios disponibles</div>');
                    }
                } else {
                    console.error('Error en la respuesta:', response.error);
                    mostrarError(response.error || 'Error al cargar usuarios');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error de AJAX:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
                mostrarError('Error de conexión al cargar usuarios');
            }
        });
    }

    // Manejar clic en usuario
    $(document).on('click', '.usuario-item', function() {
        const id = $(this).data('id');
        const nombre = $(this).data('nombre');
        
        $('.usuario-item').removeClass('activo');
        $(this).addClass('activo');
        
        usuarioActual = id;
        $('#usuario_actual').val(id);
        $('#nombre-usuario-actual').text(nombre);
        
        actualizarMensajes();
    });

    function actualizarMensajes() {
        const receptor = $('#usuario_actual').val();
        if (!receptor) return;
        
        $.ajax({
            url: 'get_mensajes.php',
            method: 'GET',
            data: { 
                usuario_id: receptor
            },
            success: function(response) {
                if (response.success) {
                    mostrarMensajes(response.mensajes);
                } else {
                    mostrarError(response.error || 'Error al cargar mensajes');
                }
            },
            error: function() {
                mostrarError('Error de conexión al cargar mensajes');
            }
        });
    }

    function mostrarMensajes(mensajes) {
        const contenedor = $('#mensajes');
        contenedor.empty();
        
        mensajes.forEach(mensaje => {
            const esEmisor = mensaje.emisor_id == usuarioId;
            const clase = esEmisor ? 'mensaje-emisor' : 'mensaje-receptor';
            const fecha = new Date(mensaje.fecha_envio).toLocaleString();
            
            // Crear el elemento del mensaje
            const elementoMensaje = $(`
                <div class="mensaje ${clase}">
                    <div class="mensaje-contenido">
                        <div class="mensaje-texto"></div>
                        <span class="mensaje-fecha">${fecha}</span>
                    </div>
                </div>
            `);

            // Crear un div temporal para parsear el HTML
            const tempDiv = $('<div>').html(mensaje.mensaje);
            
            // Separar el texto del mensaje y el adjunto
            const adjuntoElement = tempDiv.find('.adjunto-mensaje');
            let textoMensaje = tempDiv.clone().children('.adjunto-mensaje').remove().end().html();
            
            // Insertar el texto del mensaje si existe
            if (textoMensaje && textoMensaje.trim()) {
                elementoMensaje.find('.mensaje-texto').html(textoMensaje);
            }
            
            // Insertar el adjunto si existe
            if (adjuntoElement.length > 0) {
                elementoMensaje.find('.mensaje-contenido').append(adjuntoElement);
            }
            
            contenedor.append(elementoMensaje);
        });
        
        // Scroll al último mensaje
        contenedor.scrollTop(contenedor[0].scrollHeight);
    }

    function enviarMensaje() {
        const mensaje = $('#mensaje').val().trim();
        const receptor = $('#usuario_actual').val();
        const archivo = $('#archivo')[0].files[0];
        
        console.log('Validación inicial:', {
            mensaje: mensaje,
            receptor: receptor,
            tieneArchivo: !!archivo
        });

        // Verificar si hay un destinatario seleccionado
        if (!receptor) {
            mostrarError('Selecciona un usuario para enviar el mensaje');
            return;
        }

        // Verificar si hay contenido para enviar (mensaje o archivo)
        if (!mensaje && !archivo) {
            mostrarError('Debes escribir un mensaje o adjuntar un archivo');
            return;
        }
        
        console.log('Preparando envío de mensaje:', {
            receptor: receptor,
            mensaje: mensaje,
            tieneArchivo: !!archivo,
            nombreArchivo: archivo ? archivo.name : null,
            tamañoArchivo: archivo ? archivo.size : null
        });

        const formData = new FormData();
        formData.append('para', receptor);
        formData.append('mensaje', mensaje || ''); // Asegurarnos de que siempre enviamos al menos una cadena vacía
        
        if (archivo) {
            console.log('Archivo seleccionado:', {
                nombre: archivo.name,
                tipo: archivo.type,
                tamaño: archivo.size,
                ultimaModificacion: archivo.lastModified
            });
            
            formData.append('archivo', archivo);
            
            // Verificar que el archivo se añadió correctamente al FormData
            console.log('Contenido del FormData:');
            for (let pair of formData.entries()) {
                console.log(pair[0] + ': ' + (pair[1] instanceof File ? pair[1].name : pair[1]));
            }
        }
        
        // Mostrar indicador de carga
        const btnEnviar = $('#form-mensaje button[type="submit"]');
        const textoOriginal = btnEnviar.text();
        btnEnviar.prop('disabled', true).text('Enviando...');
        
        $.ajax({
            url: 'enviar_mensaje.php',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        console.log('Progreso de carga: ' + Math.round(percentComplete * 100) + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                console.log('Respuesta del servidor:', response);
                if (response.success) {
                    $('#mensaje').val('');
                    $('#archivo').val('');
                    $('#nombre-archivo').text('Adjuntar archivo');
                    actualizarMensajes();
                } else {
                    mostrarError(response.error || 'Error al enviar el mensaje');
                    console.error('Error del servidor:', response.error);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error de AJAX:', {
                    status: status,
                    error: error,
                    response: xhr.responseText,
                    estado: xhr.status,
                    statusText: xhr.statusText
                });
                mostrarError('Error de conexión al enviar el mensaje');
            },
            complete: function() {
                // Restaurar el botón
                btnEnviar.prop('disabled', false).text(textoOriginal);
            }
        });
    }

    function mostrarError(mensaje) {
        const errorDiv = $('#error-mensaje');
        errorDiv.text(mensaje).show();
        setTimeout(() => errorDiv.fadeOut(), 5000);
    }

    // Actualizar mensajes cada 3 segundos si hay un usuario seleccionado
    setInterval(() => {
        if (usuarioActual) {
            actualizarMensajes();
        }
    }, 3000);
});
