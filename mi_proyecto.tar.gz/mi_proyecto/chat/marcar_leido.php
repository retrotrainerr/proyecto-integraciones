<?php
require_once '../includes/config.php';
require_once '../includes/session.php';

$de = intval($_GET['para']);
$para = $_SESSION['usuario_id'];

$conexion->query("UPDATE mensajes SET leido = 1 WHERE emisor_id = $de AND receptor_id = $para");
