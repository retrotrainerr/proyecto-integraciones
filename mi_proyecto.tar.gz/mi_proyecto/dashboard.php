<?php
require_once 'includes/session.php';
$title = "Panel de Control";
require_once 'templates/header.php';
?>

<div class="container mt-4">
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_SESSION['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <h1 class="h3 mb-4">Bienvenido, <?= htmlspecialchars($_SESSION['usuario']) ?>!</h1>
            
            <?php if ($_SESSION['rol'] === 'Administrador'): ?>
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Gestión de Usuarios</h5>
                            <p class="card-text">Administra los usuarios del sistema.</p>
                            <a href="<?= BASE_URL ?>admin/usuarios/users.php" class="btn btn-primary">Ir a Usuarios</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Gestión de Roles</h5>
                            <p class="card-text">Configura los roles y permisos.</p>
                            <a href="<?= BASE_URL ?>admin/roles/index.php" class="btn btn-primary">Ir a Roles</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Gestión de Grupos</h5>
                            <p class="card-text">Administra los grupos de usuarios.</p>
                            <a href="<?= BASE_URL ?>admin/grupos/index.php" class="btn btn-primary">Ir a Grupos</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Chat</h5>
                            <p class="card-text">Sistema de mensajería interna.</p>
                            <a href="<?= BASE_URL ?>chat/index.php" class="btn btn-primary">Ir al Chat</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                <p class="lead mb-0">Selecciona una opción del menú para comenzar.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'templates/footer.php'; ?>
