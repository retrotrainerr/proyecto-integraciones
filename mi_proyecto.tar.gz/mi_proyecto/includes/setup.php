<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'config.php';

$conexion->query("CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    clave VARCHAR(255) NOT NULL
)");

$conexion->query("DELETE FROM usuarios WHERE usuario = 'admin'");
$hash = password_hash('admin123', PASSWORD_DEFAULT); // genera el hash en el momento
$conexion->query("DELETE FROM usuarios WHERE usuario='admin'");
$conexion->query("INSERT INTO usuarios (usuario, clave) VALUES ('admin', '$hash')");

echo "Usuario admin creado con clave: admin123";
?>