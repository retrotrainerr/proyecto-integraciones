<?php
$conexion = new mysqli("localhost", "root", "(Apz)703880", "mi_base");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// URL base del proyecto
define('BASE_URL', '/mi_proyecto/');
?>