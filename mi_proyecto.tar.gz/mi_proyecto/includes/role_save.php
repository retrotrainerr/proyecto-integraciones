<?php
require_once 'session.php';
require_once 'config.php';

if ($_SESSION['rol'] !== 'Administrador') {
    exit('Acceso denegado');
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$nombre = trim($_POST['nombre'] ?? '');

if ($nombre === '') {
    die('Nombre requerido');
}

if ($id > 0) {
    $stmt = $conexion->prepare("UPDATE roles SET nombre=? WHERE id=?");
    $stmt->bind_param("si", $nombre, $id);
} else {
    $stmt = $conexion->prepare("INSERT INTO roles (nombre) VALUES (?)");
    $stmt->bind_param("s", $nombre);
}
$stmt->execute();
$stmt->close();
header("Location: ../admin/roles/index.php");
?>
