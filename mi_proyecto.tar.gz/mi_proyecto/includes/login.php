<?php
require_once 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit();
}

$usuario = $_POST['usuario'] ?? '';
$clave = $_POST['clave'] ?? '';

if (empty($usuario) || empty($clave)) {
    header("Location: ../index.php?error=1");
    exit();
}

try {
    // Primero verificamos si el usuario existe y obtenemos su clave
    $stmt = $conexion->prepare("SELECT id, clave, rol_id FROM usuarios WHERE usuario = ?");
    
    if (!$stmt) {
        throw new Exception("Error preparando la consulta");
    }

    $stmt->bind_param("s", $usuario);
    
    if (!$stmt->execute()) {
        throw new Exception("Error ejecutando la consulta");
    }

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($clave, $user['clave'])) {
        // Si la autenticación es exitosa, obtenemos el rol
        $rol_stmt = $conexion->prepare("SELECT nombre FROM roles WHERE id = ?");
        $rol_stmt->bind_param("i", $user['rol_id']);
        $rol_stmt->execute();
        $rol_result = $rol_stmt->get_result();
        $rol_data = $rol_result->fetch_assoc();
        
        $_SESSION['usuario_id'] = $user['id'];
        $_SESSION['usuario'] = $usuario;
        $_SESSION['rol'] = $rol_data['nombre'] ?? 'Sin rol';
        
        header("Location: ../dashboard.php");
        exit();
    } else {
        header("Location: ../index.php?error=1");
        exit();
    }
} catch (Exception $e) {
    error_log("Error en login.php: " . $e->getMessage());
    header("Location: ../index.php?error=2");
    exit();
}
?>
