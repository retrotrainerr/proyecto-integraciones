<?php
require_once 'session.php';
require_once 'config.php';

if ($_SESSION['rol'] !== 'Administrador') {
    exit('Acceso denegado');
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    $stmt = $conexion->prepare("DELETE FROM roles WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
header("Location: ../admin/roles/index.php");
?>
