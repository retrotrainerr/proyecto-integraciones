<?php
session_start();

require_once __DIR__ . '/config.php';

// Si no hay sesión, redirigir al login
if (!isset($_SESSION['usuario'])) {
    header("Location: " . BASE_URL . "index.php");
    exit();
}

// Verificar y actualizar información del usuario
try {
    $stmt = $conexion->prepare("
        SELECT u.es_admin, r.nombre AS rol, u.grupo_id
        FROM usuarios u
        LEFT JOIN roles r ON u.rol_id = r.id
        WHERE u.usuario = ?
    ");
    
    if (!$stmt) {
        throw new Exception("Error preparando la consulta: " . $conexion->error);
    }
    
    $stmt->bind_param("s", $_SESSION['usuario']);
    
    if (!$stmt->execute()) {
        throw new Exception("Error ejecutando la consulta: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user) {
        $_SESSION['es_admin'] = $user['es_admin'];
        $_SESSION['rol'] = $user['rol'] ?? 'Sin rol';
        $_SESSION['grupo_id'] = $user['grupo_id'];
    } else {
        // Si no se encuentra el usuario, cerrar sesión
        session_destroy();
        header("Location: " . BASE_URL . "index.php");
        exit();
    }
    
    $stmt->close();
} catch (Exception $e) {
    error_log("Error en session.php: " . $e->getMessage());
    // En caso de error, cerrar sesión y redirigir al login
    session_destroy();
    header("Location: " . BASE_URL . "index.php?error=3");
    exit();
}
?>

