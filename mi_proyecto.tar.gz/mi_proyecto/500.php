<?php
$title = "Error del Servidor";
require_once 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <h1 class="display-1">500</h1>
            <h2>Error del Servidor</h2>
            <p class="lead">Lo sentimos, ha ocurrido un error en el servidor.</p>
            <a href="<?= BASE_URL ?>dashboard.php" class="btn btn-primary">Volver al Dashboard</a>
        </div>
    </div>
</div>

<?php require_once 'templates/footer.php'; ?> 